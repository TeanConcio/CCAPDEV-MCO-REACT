# CCAPDEV-MCO



1. Unzip the Folder
2. Open the folder in VSCode, or any code editor with a terminal
3. right click server folder, and press open in integrated terminal (or just find path of server), THEN, type npm -i.
4. After installing everything needed for the server, type npm run dev
4.5. (If you arent able to connect to the database, login in MongoDB with the following credentials: username/email: password: , go to network settings and add your ip address to whitelist it)
5. Right click the client folder, and press open in integrated terminal (or just find path of client), THEN type npm -i
6. After installing everything needed for the client, type npm start.




Email and Password to Database:
antesemetichustasa@gmail.com
antesemetic0